purgeAll();

